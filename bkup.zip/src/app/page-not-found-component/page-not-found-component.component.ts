import { Component } from '@angular/core';

@Component({
  selector: 'app-page-not-found-component',
  standalone: true,
  imports: [],
  templateUrl: './page-not-found-component.component.html',
  styleUrl: './page-not-found-component.component.sass'
})
export class PageNotFoundComponentComponent {

}
